7/12/2018:
    Bug Fixed, added missing SEALEVELPRESSURE_HPA into OpenCansatLite.ino

26/9/2018:
    First release of the SW